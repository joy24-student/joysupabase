import { useQueryClient } from '@tanstack/react-query'
import {
  AuthProvider as AuthProviderInternal,
  clearLocalStorage,
  gotrueClient,
  posthogClient,
  useAuthError,
} from 'common'
import { PropsWithChildren, useCallback, useEffect } from 'react'
import { toast } from 'sonner'

import { GOTRUE_ERRORS, IS_PLATFORM } from './constants'
import { useAiAssistantStateSnapshot } from '@/state/ai-assistant-state'

const AuthErrorToaster = ({ children }: PropsWithChildren) => {
  const error = useAuthError()

  useEffect(() => {
    if (error !== null) {
      if (error.message === GOTRUE_ERRORS.UNVERIFIED_GITHUB_USER) {
        toast.error(
          'Please verify your email on GitHub first, then reach out to us at support@supabase.io to log into the dashboard'
        )
        return
      }

      toast.error(error.message)
    }
  }, [error])

  return children
}

export const AuthProvider = ({ children }: PropsWithChildren) => {
  return (
    <AuthProviderInternal alwaysLoggedIn={!IS_PLATFORM}>
      <AuthErrorToaster>{children}</AuthErrorToaster>
    </AuthProviderInternal>
  )
}

export function useSignOut() {
  const queryClient = useQueryClient()
  const { clearStorage: clearAssistantStorage } = useAiAssistantStateSnapshot()

  return useCallback(async () => {
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem('supabase.firebase.auth.token')
      window.localStorage.removeItem('supabase.dashboard.auth.token')
    }
    try {
      const { firebaseAuth } = await import('@/lib/firebase/client')
      await firebaseAuth.signOut()
    } catch {}
    const result = await gotrueClient.signOut()
    posthogClient.reset()
    clearLocalStorage()
    await clearAssistantStorage()
    queryClient.clear()

    return result
  }, [queryClient, clearAssistantStorage])
}
