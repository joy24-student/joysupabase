import * as Sentry from '@sentry/nextjs'
import type { JwtPayload } from '@supabase/supabase-js'
import type { NextApiRequest, NextApiResponse } from 'next'

import { IS_PLATFORM } from '../constants'
import { apiAuthenticate } from './apiAuthenticate'
import { encryptString, getConnectionString } from './self-hosted/util'
import { ResponseError, ResponseFailure } from '@/types'

export function isResponseOk<T>(response: T | ResponseFailure | undefined): response is T {
  if (response === undefined || response === null) {
    return false
  }

  if (response instanceof ResponseError) {
    return false
  }

  if (typeof response === 'object' && 'error' in response && Boolean(response.error)) {
    return false
  }

  return true
}

export async function apiWrapper(
  req: NextApiRequest,
  res: NextApiResponse,
  handler: (
    req: NextApiRequest,
    res: NextApiResponse,
    claims?: JwtPayload
  ) => Promise<NextApiResponse | Response | void>,
  options?: { withAuth: boolean }
): Promise<NextApiResponse | Response | void> {
  try {
    const { withAuth } = options || {}
    let claims: JwtPayload | undefined

    if (IS_PLATFORM && withAuth) {
      const response = await apiAuthenticate(req, res)
      if (!isResponseOk(response)) {
        return res.status(401).json({
          error: {
            message: `Unauthorized: ${response.error.message}`,
          },
        })
      }
      claims = response
    }

    // Automatically attach x-connection-encrypted for pg-meta routes based on project ref
    if (!req.headers['x-connection-encrypted']) {
      try {
        const ref = typeof req.query?.ref === 'string' ? req.query.ref : undefined
        let connectionString: string | undefined
        if (ref && ref !== 'default') {
          const { getProjectByRef } = await import('./db')
          const project = await getProjectByRef(ref)
          if (project) {
            connectionString = `postgresql://${project.db_user}:${project.db_password}@${project.db_host}:${project.db_port}/${project.db_name}`
          }
        }
        if (!connectionString) {
          connectionString = getConnectionString({ readOnly: false })
        }
        req.headers['x-connection-encrypted'] = encryptString(connectionString)
      } catch {}
    }

    return await handler(req, res, claims)
  } catch (error) {
    Sentry.captureException(error)
    return res.status(500).json({ error })
  }
}
