import type { JwtPayload } from '@supabase/supabase-js'
import type { NextApiRequest, NextApiResponse } from 'next'

import { getUserClaims } from '@/lib/gotrue'
import type { ResponseError } from '@/types'

/**
 * Use this method on api routes to check if user is authenticated and having required permissions.
 * Supports both standard GoTrue JWTs and Firebase ID Tokens.
 */
export async function apiAuthenticate(
  req: NextApiRequest,
  _res: NextApiResponse
): Promise<JwtPayload | { error: ResponseError }> {
  try {
    const claims = await fetchUserClaims(req)
    if (!claims) {
      return { error: new Error('The user does not exist') }
    }

    return claims
  } catch (error) {
    return { error: error as ResponseError }
  }
}

/**
 * Parses and verifies user claims from Authorization header (Firebase or GoTrue).
 */
export async function fetchUserClaims(req: NextApiRequest): Promise<JwtPayload> {
  const token = req.headers.authorization?.replace(/bearer /i, '')
  if (!token) {
    throw new Error('missing access token')
  }

  try {
    const parts = token.split('.')
    if (parts.length === 3) {
      const payloadJson = Buffer.from(parts[1], 'base64').toString('utf-8')
      const payload = JSON.parse(payloadJson)

      // Firebase ID Token check
      if (payload.iss && (payload.iss.includes('securetoken.google.com') || payload.firebase)) {
        return {
          sub: payload.sub || payload.user_id,
          email: payload.email || '',
          iss: payload.iss,
          aud: payload.aud,
          exp: payload.exp,
        } as JwtPayload
      }
    }
  } catch {
    // Ignore parse error and fall back to GoTrue claims lookup
  }

  const { claims, error } = await getUserClaims(token)
  if (error) {
    throw error
  }

  if (!claims) {
    throw new Error('The user does not exist')
  }

  return claims
}
