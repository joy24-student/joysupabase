import { executeQuery } from './self-hosted/query'

// Initialize metadata schema and tables if they do not exist
let initialized = false

export async function ensureMetadataTables() {
  if (initialized) return
  initialized = true

  const initSql = `
    CREATE SCHEMA IF NOT EXISTS _studio_metadata;

    CREATE TABLE IF NOT EXISTS _studio_metadata.organizations (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      billing_email TEXT NOT NULL,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS _studio_metadata.members (
      id SERIAL PRIMARY KEY,
      organization_id INTEGER REFERENCES _studio_metadata.organizations(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'owner',
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(organization_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS _studio_metadata.projects (
      id SERIAL PRIMARY KEY,
      ref TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      organization_id INTEGER REFERENCES _studio_metadata.organizations(id) ON DELETE CASCADE,
      db_host TEXT NOT NULL,
      db_port INTEGER NOT NULL DEFAULT 5432,
      db_name TEXT NOT NULL,
      db_user TEXT NOT NULL,
      db_password TEXT NOT NULL,
      anon_key TEXT NOT NULL,
      service_key TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'ACTIVE_HEALTHY',
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );
  `
  try {
    const res = await executeQuery({ query: initSql })
    if (res.error) {
      console.error('Failed to initialize metadata tables:', res.error)
    }
  } catch (err) {
    console.error('Error during metadata tables initialization:', err)
  }
}

export async function getOrganizationsForUser(userId: string) {
  await ensureMetadataTables()

  const sql = `
    SELECT o.* FROM _studio_metadata.organizations o
    JOIN _studio_metadata.members m ON m.organization_id = o.id
    WHERE m.user_id = $1
    ORDER BY o.name ASC;
  `
  const res = await executeQuery<any>({ query: sql, parameters: [userId] })
  if (res.error) throw res.error
  return res.data || []
}

export async function createOrganizationForUser(userId: string, name: string, slug: string, billingEmail: string) {
  await ensureMetadataTables()

  // Start a transaction-like execution or run sequentially
  const createOrgSql = `
    INSERT INTO _studio_metadata.organizations (name, slug, billing_email)
    VALUES ($1, $2, $3)
    RETURNING *;
  `
  const orgRes = await executeQuery<any>({ query: createOrgSql, parameters: [name, slug, billingEmail] })
  if (orgRes.error) throw orgRes.error
  const newOrg = orgRes.data?.[0]

  if (!newOrg) {
    throw new Error('Failed to create organization')
  }

  const createMemberSql = `
    INSERT INTO _studio_metadata.members (organization_id, user_id, role)
    VALUES ($1, $2, 'owner')
    RETURNING *;
  `
  const memberRes = await executeQuery<any>({ query: createMemberSql, parameters: [newOrg.id, userId] })
  if (memberRes.error) throw memberRes.error

  return newOrg
}

export async function getProjectsForUser(userId: string) {
  await ensureMetadataTables()

  const sql = `
    SELECT p.* FROM _studio_metadata.projects p
    JOIN _studio_metadata.organizations o ON p.organization_id = o.id
    JOIN _studio_metadata.members m ON m.organization_id = o.id
    WHERE m.user_id = $1
    ORDER BY p.name ASC;
  `
  const res = await executeQuery<any>({ query: sql, parameters: [userId] })
  if (res.error) throw res.error
  return res.data || []
}

export async function createProject(
  orgId: number,
  ref: string,
  name: string,
  dbHost: string,
  dbPort: number,
  dbName: string,
  dbUser: string,
  dbPass: string,
  anonKey: string,
  serviceKey: string
) {
  await ensureMetadataTables()

  const sql = `
    INSERT INTO _studio_metadata.projects (
      organization_id, ref, name, db_host, db_port, db_name, db_user, db_password, anon_key, service_key, status
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'ACTIVE_HEALTHY')
    RETURNING *;
  `
  const res = await executeQuery<any>({
    query: sql,
    parameters: [orgId, ref, name, dbHost, dbPort, dbName, dbUser, dbPass, anonKey, serviceKey]
  })
  if (res.error) throw res.error
  return res.data?.[0]
}

export async function getProjectByRef(ref: string) {
  await ensureMetadataTables()

  const sql = `
    SELECT * FROM _studio_metadata.projects
    WHERE ref = $1;
  `
  const res = await executeQuery<any>({ query: sql, parameters: [ref] })
  if (res.error) throw res.error
  return res.data?.[0]
}
