import { useQuery } from '@tanstack/react-query'

import { projectKeys } from './keys'
import { buildPauseStatus, getPauseStatusOverride } from './project-pause-status-override'
import { get, handleError } from '@/data/fetchers'
import type { ResponseError, UseCustomQueryOptions } from '@/types'

export type ProjectPauseStatusVariables = { ref?: string }

export async function getProjectPausedStatus(
  { ref }: ProjectPauseStatusVariables,
  signal?: AbortSignal
) {
  if (!ref) throw new Error('Project ref is required')

  const override = getPauseStatusOverride(ref)
  if (override) return buildPauseStatus(override)

  const { data, error } = await get('/platform/projects/{ref}/pause/status', {
    params: { path: { ref } },
    signal,
  })

  if (error) handleError(error)
  return data
}

export type ProjectPauseStatusData = Awaited<ReturnType<typeof getProjectPausedStatus>>
export type ProjectPauseStatusError = ResponseError

export const useProjectPauseStatusQuery = <TData = ProjectPauseStatusData>(
  { ref }: ProjectPauseStatusVariables,
  {
    enabled = true,
    ...options
  }: UseCustomQueryOptions<ProjectPauseStatusData, ProjectPauseStatusError, TData> = {}
) =>
  useQuery<ProjectPauseStatusData, ProjectPauseStatusError, TData>({
    queryKey: projectKeys.pauseStatus(ref),
    queryFn: ({ signal }) => getProjectPausedStatus({ ref }, signal),
    enabled: enabled && typeof ref !== 'undefined',
    ...options,
  })
