import { FirebaseAuthForm } from '@/components/interfaces/SignIn/FirebaseAuthForm'
import { AuthenticationLayout } from '@/components/layouts/AuthenticationLayout'
import { SignInLayout } from '@/components/layouts/SignInLayout/SignInLayout'
import type { NextPageWithLayout } from '@/types'

const SignInPage: NextPageWithLayout = () => {
  return <FirebaseAuthForm />
}

SignInPage.getLayout = (page) => (
  <AuthenticationLayout>
    <SignInLayout
      heading="Welcome"
      subheading="Sign in or create your account using Firebase Auth"
      logoLinkToMarketingSite={false}
      inboundFlow="sign-in"
    >
      {page}
    </SignInLayout>
  </AuthenticationLayout>
)

export default SignInPage
