import type { NextApiRequest, NextApiResponse } from 'next'

import { apiWrapper } from '@/lib/api/apiWrapper'

export default (req: NextApiRequest, res: NextApiResponse) =>
  apiWrapper(req, res, async (req, res) => {
    const slugParts = Array.isArray(req.query.slug) ? req.query.slug : [req.query.slug || '']
    const path = '/' + slugParts.join('/')

    if (path.endsWith('/notifications/summary')) {
      return res.status(200).json({
        unread_count: 0,
        has_critical: false,
        has_warning: false,
      })
    }

    if (path.endsWith('/notifications') || path.endsWith('/notifications/archive-all')) {
      return res.status(200).json([])
    }

    if (path.startsWith('/telemetry')) {
      return res.status(200).json({})
    }

    if (path.endsWith('/projects/available-regions')) {
      const region = {
        code: 'SOUTHEAST_ASIA',
        name: 'Southeast Asia (Singapore)',
        type: 'specific',
        provider: 'AWS',
        status: 'capacity',
      }
      const smartGroup = {
        code: 'APAC',
        name: 'Asia-Pacific',
        type: 'smartGroup',
      }
      return res.status(200).json({
        all: {
          smartGroup: [smartGroup],
          specific: [region],
        },
        recommendations: {
          smartGroup,
          specific: [region],
        },
      })
    }

    if (path.endsWith('/status')) {
      return res.status(200).json({ status: 'ACTIVE_HEALTHY' })
    }

    if (path.endsWith('/pause/status')) {
      return res.status(200).json({
        status: 'ACTIVE_HEALTHY',
        can_pause: false,
        max_paused_days: null,
        remaining_days_till_restore_disabled: null,
      })
    }

    if (path.endsWith('/service-versions')) {
      return res.status(200).json({
        postgres: '15.8.1',
        gotrue: 'v2.170.0',
        postgrest: 'v12.2.8',
      })
    }

    if (path.endsWith('/mfa/enforcement')) {
      return res.status(200).json({ enforced: false })
    }

    if (
      path.endsWith('/overdue') ||
      path.endsWith('/reached-free-project-limit') ||
      path.endsWith('/oauth/apps') ||
      path.endsWith('/invitations') ||
      path.endsWith('/payments') ||
      path.endsWith('/tax-ids') ||
      path.endsWith('/invoices') ||
      path.endsWith('/audit') ||
      path.endsWith('/members')
    ) {
      return res.status(200).json([])
    }

    if (path.endsWith('/roles')) {
      return res.status(200).json({
        org_scoped_roles: [
          { id: 1, name: 'Owner', base_role_id: 1, description: 'Owner' },
        ],
        project_scoped_roles: [],
      })
    }

    return res.status(200).json({})
  })
