import { NextApiRequest, NextApiResponse } from 'next'

import { apiWrapper } from '@/lib/api/apiWrapper'
import { getProjectByRef } from '@/lib/api/db'
import { DEFAULT_PROJECT, PROJECT_REST_URL } from '@/lib/constants/api'

export default (req: NextApiRequest, res: NextApiResponse) => apiWrapper(req, res, handler)

async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { method } = req

  switch (method) {
    case 'GET':
      return handleGet(req, res)
    case 'PATCH':
      return handleGet(req, res)
    default:
      res.setHeader('Allow', ['GET', 'PATCH'])
      res.status(405).json({ data: null, error: { message: `Method ${method} Not Allowed` } })
  }
}

const handleGet = async (req: NextApiRequest, res: NextApiResponse) => {
  const ref = typeof req.query.ref === 'string' ? req.query.ref : 'default'
  try {
    const project = await getProjectByRef(ref)
    if (project) {
      return res.status(200).json({
        ...DEFAULT_PROJECT,
        id: project.id,
        ref: project.ref,
        name: project.name,
        organization_id: project.organization_id,
        status: project.status || 'ACTIVE_HEALTHY',
        connectionString: '',
        restUrl: PROJECT_REST_URL,
      })
    }
  } catch {}

  const response = {
    ...DEFAULT_PROJECT,
    ref,
    connectionString: '',
    restUrl: PROJECT_REST_URL,
  }

  return res.status(200).json(response)
}
