import type { NextApiRequest, NextApiResponse } from 'next'
import type { JwtPayload } from '@supabase/supabase-js'

import { apiWrapper } from '@/lib/api/apiWrapper'
import {
  getProjectsForUser,
  getOrganizationsForUser,
  createProject,
} from '@/lib/api/db'
import { executeQuery } from '@/lib/api/self-hosted/query'

export default (req: NextApiRequest, res: NextApiResponse) =>
  apiWrapper(req, res, handler, { withAuth: true })

async function handler(req: NextApiRequest, res: NextApiResponse, claims?: JwtPayload) {
  const { method } = req

  if (!claims || !claims.sub) {
    return res.status(401).json({ error: { message: 'Unauthorized: missing user claims' } })
  }

  const userId = claims.sub

  switch (method) {
    case 'GET':
      return handleGet(req, res, userId)
    case 'POST':
      return handlePost(req, res, userId)
    default:
      res.setHeader('Allow', ['GET', 'POST'])
      res.status(405).json({ data: null, error: { message: `Method ${method} Not Allowed` } })
  }
}

const handleGet = async (req: NextApiRequest, res: NextApiResponse, userId: string) => {
  try {
    const orgs = await getOrganizationsForUser(userId)
    const dbProjects = await getProjectsForUser(userId)

    const response = dbProjects.map((p: any) => {
      const org = orgs.find((o: any) => o.id === p.organization_id)
      return {
        id: p.id,
        ref: p.ref,
        name: p.name,
        organization_id: p.organization_id,
        organization_slug: org?.slug || 'default',
        cloud_provider: 'AWS',
        status: p.status || 'ACTIVE_HEALTHY',
        region: 'SOUTHEAST_ASIA',
        inserted_at: p.created_at || new Date().toISOString(),
        databases: [
          {
            identifier: p.ref,
            infra_compute_size: 'micro',
            region: 'SOUTHEAST_ASIA',
            status: p.status || 'ACTIVE_HEALTHY',
            cloud_provider: 'AWS',
          },
        ],
      }
    })

    if (req.headers['version'] === '2' || req.query.limit !== undefined) {
      return res.status(200).json({
        projects: response,
        pagination: {
          count: response.length,
          limit: Number(req.query.limit) || 100,
          offset: Number(req.query.offset) || 0,
        },
      })
    }

    return res.status(200).json(response)
  } catch (error: any) {
    console.error('Error fetching projects:', error)
    return res.status(500).json({ error: { message: error.message || 'Internal Server Error' } })
  }
}

const handlePost = async (req: NextApiRequest, res: NextApiResponse, userId: string) => {
  try {
    const { name, organization_slug, organization_id, db_pass } = req.body

    if (!name) {
      return res.status(400).json({ error: { message: 'Project name is required' } })
    }

    const userOrgs = await getOrganizationsForUser(userId)
    const targetOrg =
      userOrgs.find((o: any) => o.slug === organization_slug || o.id === organization_id) ||
      userOrgs[0]

    if (!targetOrg) {
      return res.status(403).json({ error: { message: 'Organization not found or permission denied' } })
    }

    const randStr = Math.random().toString(36).substring(2, 8)
    const ref = `proj-${randStr}`
    const isolatedDbName = `db_${ref.replace(/[^a-zA-Z0-9]/g, '_')}`

    try {
      await executeQuery({ query: `CREATE DATABASE "${isolatedDbName}";` })
    } catch (dbErr) {
      console.warn(`Database "${isolatedDbName}" provision note:`, dbErr)
    }

    const dbHost = process.env.POSTGRES_HOST || 'db'
    const dbPort = parseInt(process.env.POSTGRES_PORT || '5432')
    const dbUser = process.env.POSTGRES_USER_READ_WRITE || 'postgres'
    const password = db_pass || process.env.POSTGRES_PASSWORD || ''
    const anonKey = process.env.SUPABASE_ANON_KEY || ''
    const serviceKey = process.env.SUPABASE_SERVICE_KEY || ''

    const newProject = await createProject(
      targetOrg.id,
      ref,
      name,
      dbHost,
      dbPort,
      isolatedDbName,
      dbUser,
      password,
      anonKey,
      serviceKey
    )

    const response = {
      id: newProject.id,
      ref: newProject.ref,
      name: newProject.name,
      organization_id: newProject.organization_id,
      organization_slug: targetOrg.slug,
      cloud_provider: 'AWS',
      status: newProject.status || 'ACTIVE_HEALTHY',
      region: 'SOUTHEAST_ASIA',
      inserted_at: newProject.created_at || new Date().toISOString(),
      anon_key: anonKey,
      service_key: serviceKey,
      endpoint: process.env.SUPABASE_PUBLIC_URL || 'https://swapno.duckdns.org',
    }

    return res.status(200).json(response)
  } catch (error: any) {
    console.error('Error creating project:', error)
    return res.status(500).json({ error: { message: error.message || 'Internal Server Error' } })
  }
}
