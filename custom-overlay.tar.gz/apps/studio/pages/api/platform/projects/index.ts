import type { NextApiRequest, NextApiResponse } from 'next'
import type { JwtPayload } from '@supabase/supabase-js'

import { apiWrapper } from '@/lib/api/apiWrapper'
import {
  getProjectsForUser,
  getOrganizationsForUser,
  createProject
} from '@/lib/api/db'
import { executeQuery } from '@/lib/api/self-hosted/query'

export default (req: NextApiRequest, res: NextApiResponse) =>
  apiWrapper(req, res, handler, { withAuth: true })

async function handler(req: NextApiRequest, res: NextApiResponse, claims?: JwtPayload) {
  const { method } = req

  if (!claims || !claims.sub) {
    return res.status(401).json({ error: { message: 'Unauthorized: missing user claims' } })
  }

  const userId = claims.sub

  switch (method) {
    case 'GET':
      return handleGet(req, res, userId)
    case 'POST':
      return handlePost(req, res, userId)
    default:
      res.setHeader('Allow', ['GET', 'POST'])
      res.status(405).json({ data: null, error: { message: `Method ${method} Not Allowed` } })
  }
}

const handleGet = async (_req: NextApiRequest, res: NextApiResponse, userId: string) => {
  try {
    const dbProjects = await getProjectsForUser(userId)

    const response = dbProjects.map((p: any) => ({
      id: p.id,
      ref: p.ref,
      name: p.name,
      organization_id: p.organization_id,
      cloud_provider: 'localhost',
      status: p.status || 'ACTIVE_HEALTHY',
      region: 'local',
      inserted_at: p.created_at || new Date().toISOString(),
    }))

    return res.status(200).json(response)
  } catch (error: any) {
    console.error('Error fetching projects:', error)
    return res.status(500).json({ error: { message: error.message || 'Internal Server Error' } })
  }
}

const handlePost = async (req: NextApiRequest, res: NextApiResponse, userId: string) => {
  try {
    const { name, organization_slug, db_pass } = req.body

    if (!name || !organization_slug) {
      return res.status(400).json({ error: { message: 'Project name and organization_slug are required' } })
    }

    const userOrgs = await getOrganizationsForUser(userId)
    const targetOrg = userOrgs.find((o: any) => o.slug === organization_slug)

    if (!targetOrg) {
      return res.status(403).json({ error: { message: 'Organization not found or permission denied' } })
    }

    const randStr = Math.random().toString(36).substring(2, 8)
    const ref = `proj-${randStr}`
    const isolatedDbName = `db_${ref.replace(/[^a-zA-Z0-9]/g, '_')}`

    // Provision an isolated PostgreSQL database for this specific project/user
    try {
      await executeQuery({ query: `CREATE DATABASE "${isolatedDbName}";` })
    } catch (dbErr) {
      console.warn(`Database "${isolatedDbName}" provision note:`, dbErr)
    }

    const dbHost = process.env.POSTGRES_HOST || 'localhost'
    const dbPort = parseInt(process.env.POSTGRES_PORT || '5432')
    const dbUser = process.env.POSTGRES_USER_READ_WRITE || 'postgres'
    const password = db_pass || process.env.POSTGRES_PASSWORD || ''
    const anonKey = process.env.SUPABASE_ANON_KEY || ''
    const serviceKey = process.env.SUPABASE_SERVICE_KEY || ''

    const newProject = await createProject(
      targetOrg.id,
      ref,
      name,
      dbHost,
      dbPort,
      isolatedDbName,
      dbUser,
      password,
      anonKey,
      serviceKey
    )

    const response = {
      id: newProject.id,
      ref: newProject.ref,
      name: newProject.name,
      organization_id: newProject.organization_id,
      cloud_provider: 'localhost',
      status: newProject.status || 'ACTIVE_HEALTHY',
      region: 'local',
      inserted_at: newProject.created_at || new Date().toISOString(),
    }

    return res.status(200).json(response)
  } catch (error: any) {
    console.error('Error creating project:', error)
    return res.status(500).json({ error: { message: error.message || 'Internal Server Error' } })
  }
}
