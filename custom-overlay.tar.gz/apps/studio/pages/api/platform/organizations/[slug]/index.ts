import type { JwtPayload } from '@supabase/supabase-js'
import type { NextApiRequest, NextApiResponse } from 'next'

import { apiWrapper } from '@/lib/api/apiWrapper'
import { getOrganizationsForUser } from '@/lib/api/db'

export default (req: NextApiRequest, res: NextApiResponse) =>
  apiWrapper(req, res, handler, { withAuth: true })

async function handler(req: NextApiRequest, res: NextApiResponse, claims?: JwtPayload) {
  if (!claims || !claims.sub) {
    return res.status(401).json({ error: { message: 'Unauthorized' } })
  }

  const slug = String(req.query.slug || '')
  const orgs = await getOrganizationsForUser(claims.sub)
  const org = orgs.find((o: any) => o.slug === slug) || orgs[0]

  if (!org) {
    return res.status(404).json({ error: { message: 'Organization not found' } })
  }

  return res.status(200).json({
    id: org.id,
    name: org.name,
    slug: org.slug,
    billing_email: org.billing_email,
    billing_partner: null,
    organization_requires_mfa: false,
    opt_in_tags: [],
    restriction_status: null,
    restriction_data: null,
    usage_billing_enabled: false,
    stripe_customer_id: null,
    subscription_id: 'enterprise-sub',
    plan: {
      id: 'enterprise',
      name: 'Enterprise',
    },
  })
}
