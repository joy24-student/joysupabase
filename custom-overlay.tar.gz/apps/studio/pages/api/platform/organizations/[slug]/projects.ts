import type { JwtPayload } from '@supabase/supabase-js'
import type { NextApiRequest, NextApiResponse } from 'next'

import { apiWrapper } from '@/lib/api/apiWrapper'
import { getOrganizationsForUser, getProjectsForUser } from '@/lib/api/db'

export default (req: NextApiRequest, res: NextApiResponse) =>
  apiWrapper(req, res, handler, { withAuth: true })

async function handler(req: NextApiRequest, res: NextApiResponse, claims?: JwtPayload) {
  if (!claims || !claims.sub) {
    return res.status(401).json({ error: { message: 'Unauthorized' } })
  }

  const userId = claims.sub
  const slug = String(req.query.slug || '')

  try {
    const orgs = await getOrganizationsForUser(userId)
    const org = orgs.find((o: any) => o.slug === slug) || orgs[0]
    const allProjects = await getProjectsForUser(userId)
    const orgProjects = org
      ? allProjects.filter((p: any) => p.organization_id === org.id)
      : allProjects

    const formatted = orgProjects.map((p: any) => ({
      id: p.id,
      ref: p.ref,
      name: p.name,
      status: p.status || 'ACTIVE_HEALTHY',
      organization_id: p.organization_id,
      organization_slug: org?.slug || slug,
      cloud_provider: 'AWS',
      region: 'SOUTHEAST_ASIA',
      inserted_at: p.created_at || new Date().toISOString(),
      is_branch: false,
      preview_branch_refs: [],
      databases: [
        {
          identifier: p.ref,
          infra_compute_size: 'micro',
          region: 'SOUTHEAST_ASIA',
          status: p.status || 'ACTIVE_HEALTHY',
          cloud_provider: 'AWS',
        },
      ],
    }))

    return res.status(200).json({
      projects: formatted,
      pagination: {
        count: formatted.length,
        limit: 96,
        offset: 0,
      },
    })
  } catch (error: any) {
    return res.status(500).json({ error: { message: error.message || 'Internal Server Error' } })
  }
}
