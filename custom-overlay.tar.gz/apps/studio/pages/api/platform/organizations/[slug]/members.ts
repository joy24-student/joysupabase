import type { JwtPayload } from '@supabase/supabase-js'
import type { NextApiRequest, NextApiResponse } from 'next'

import { apiWrapper } from '@/lib/api/apiWrapper'

export default (req: NextApiRequest, res: NextApiResponse) =>
  apiWrapper(req, res, handler, { withAuth: true })

async function handler(_req: NextApiRequest, res: NextApiResponse, claims?: JwtPayload) {
  const email = claims?.email || 'user@example.com'
  return res.status(200).json([
    {
      gotrue_id: claims?.sub || 'firebase-user',
      primary_email: email,
      username: email.split('@')[0],
      role_ids: [1],
      mfa_enabled: false,
    },
  ])
}
