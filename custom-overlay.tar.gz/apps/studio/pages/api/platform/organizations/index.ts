import type { NextApiRequest, NextApiResponse } from 'next'
import type { JwtPayload } from '@supabase/supabase-js'

import { apiWrapper } from '@/lib/api/apiWrapper'
import {
  getOrganizationsForUser,
  createOrganizationForUser,
  createProject
} from '@/lib/api/db'

export default (req: NextApiRequest, res: NextApiResponse) =>
  apiWrapper(req, res, handler, { withAuth: true })

async function handler(req: NextApiRequest, res: NextApiResponse, claims?: JwtPayload) {
  const { method } = req

  if (!claims || !claims.sub) {
    return res.status(401).json({ error: { message: 'Unauthorized: missing user claims' } })
  }

  const userId = claims.sub
  const userEmail = claims.email || 'billing@supabase.co'

  switch (method) {
    case 'GET':
      return handleGet(req, res, userId, userEmail)
    case 'POST':
      return handlePost(req, res, userId, userEmail)
    default:
      res.setHeader('Allow', ['GET', 'POST'])
      res.status(405).json({ data: null, error: { message: `Method ${method} Not Allowed` } })
  }
}

const handleGet = async (_req: NextApiRequest, res: NextApiResponse, userId: string, userEmail: string) => {
  try {
    let orgs = await getOrganizationsForUser(userId)

    // If this is a new user and has no organizations, auto-provision a default one
    if (orgs.length === 0) {
      const defaultOrgName = process.env.DEFAULT_ORGANIZATION_NAME || 'Default Organization'
      const defaultOrgSlug = `default-${userId.substring(0, 8)}`
      
      const newOrg = await createOrganizationForUser(userId, defaultOrgName, defaultOrgSlug, userEmail)
      
      // Auto-provision a default project for this user's organization pointing to the local self-hosted DB
      const defaultProjName = process.env.DEFAULT_PROJECT_NAME || 'Default Project'
      await createProject(
        newOrg.id,
        'default', // ref is default
        defaultProjName,
        process.env.POSTGRES_HOST || 'localhost',
        parseInt(process.env.POSTGRES_PORT || '5432'),
        process.env.POSTGRES_DB || 'postgres',
        process.env.POSTGRES_USER_READ_WRITE || 'postgres',
        process.env.POSTGRES_PASSWORD || '',
        process.env.SUPABASE_ANON_KEY || '',
        process.env.SUPABASE_SERVICE_KEY || ''
      )

      orgs = [newOrg]
    }

    const response = orgs.map((org: any) => ({
      id: org.id,
      name: org.name,
      slug: org.slug,
      billing_email: org.billing_email,
      plan: {
        id: 'enterprise',
        name: 'Enterprise',
      },
    }))

    return res.status(200).json(response)
  } catch (error: any) {
    console.error('Error fetching organizations:', error)
    return res.status(500).json({ error: { message: error.message || 'Internal Server Error' } })
  }
}

const handlePost = async (req: NextApiRequest, res: NextApiResponse, userId: string, userEmail: string) => {
  try {
    const { name } = req.body
    if (!name) {
      return res.status(400).json({ error: { message: 'Organization name is required' } })
    }

    const baseSlug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-')
    const uniqueSlug = `${baseSlug}-${Math.random().toString(36).substring(2, 6)}`

    const newOrg = await createOrganizationForUser(userId, name, uniqueSlug, userEmail)

    const response = {
      id: newOrg.id,
      name: newOrg.name,
      slug: newOrg.slug,
      billing_email: newOrg.billing_email,
      plan: {
        id: 'enterprise',
        name: 'Enterprise',
      },
    }

    return res.status(200).json(response)
  } catch (error: any) {
    console.error('Error creating organization:', error)
    return res.status(500).json({ error: { message: error.message || 'Internal Server Error' } })
  }
}
