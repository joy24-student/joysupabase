import type { NextApiRequest, NextApiResponse } from 'next'
import type { JwtPayload } from '@supabase/supabase-js'

import { apiWrapper } from '@/lib/api/apiWrapper'
import {
  getOrganizationsForUser,
  createOrganizationForUser,
  createProject,
  getProjectByRef,
} from '@/lib/api/db'
import { executeQuery } from '@/lib/api/self-hosted/query'

export default (req: NextApiRequest, res: NextApiResponse) =>
  apiWrapper(req, res, handler, { withAuth: true })

async function handler(req: NextApiRequest, res: NextApiResponse, claims?: JwtPayload) {
  const { method } = req

  if (!claims || !claims.sub) {
    return res.status(401).json({ error: { message: 'Unauthorized: missing user claims' } })
  }

  const userId = claims.sub
  const userEmail = claims.email || 'billing@supabase.co'

  switch (method) {
    case 'GET':
      return handleGet(req, res, userId, userEmail)
    case 'POST':
      return handlePost(req, res, userId, userEmail)
    default:
      res.setHeader('Allow', ['GET', 'POST'])
      res.status(405).json({ data: null, error: { message: `Method ${method} Not Allowed` } })
  }
}

const handleGet = async (_req: NextApiRequest, res: NextApiResponse, userId: string, userEmail: string) => {
  try {
    let orgs = await getOrganizationsForUser(userId)

    if (orgs.length === 0) {
      const defaultOrgName = process.env.DEFAULT_ORGANIZATION_NAME || 'Default Organization'
      const cleanId = userId.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 8) || Math.random().toString(36).substring(2, 8)
      const defaultOrgSlug = `org-${cleanId}`

      const newOrg = await createOrganizationForUser(userId, defaultOrgName, defaultOrgSlug, userEmail)

      const defaultProjName = process.env.DEFAULT_PROJECT_NAME || 'Default Project'
      const existingDefault = await getProjectByRef('default')
      let projRef = 'default'
      let dbName = process.env.POSTGRES_DB || 'postgres'

      if (existingDefault) {
        projRef = `proj-${cleanId}`
        dbName = `db_${projRef.replace(/[^a-zA-Z0-9]/g, '_')}`
        try {
          await executeQuery({ query: `CREATE DATABASE "${dbName}";` })
        } catch {}
      }

      await createProject(
        newOrg.id,
        projRef,
        defaultProjName,
        process.env.POSTGRES_HOST || 'db',
        parseInt(process.env.POSTGRES_PORT || '5432'),
        dbName,
        process.env.POSTGRES_USER_READ_WRITE || 'postgres',
        process.env.POSTGRES_PASSWORD || '',
        process.env.SUPABASE_ANON_KEY || '',
        process.env.SUPABASE_SERVICE_KEY || ''
      )

      orgs = [newOrg]
    }

    const response = orgs.map((org: any) => ({
      id: org.id,
      name: org.name,
      slug: org.slug,
      billing_email: org.billing_email,
      billing_partner: null,
      organization_requires_mfa: false,
      opt_in_tags: [],
      restriction_status: null,
      restriction_data: null,
      usage_billing_enabled: false,
      stripe_customer_id: null,
      subscription_id: 'enterprise-sub',
      plan: {
        id: 'enterprise',
        name: 'Enterprise',
      },
    }))

    return res.status(200).json(response)
  } catch (error: any) {
    console.error('Error fetching organizations:', error)
    return res.status(500).json({ error: { message: error.message || 'Internal Server Error' } })
  }
}

const handlePost = async (req: NextApiRequest, res: NextApiResponse, userId: string, userEmail: string) => {
  try {
    const { name } = req.body
    if (!name) {
      return res.status(400).json({ error: { message: 'Organization name is required' } })
    }

    const baseSlug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'org'
    const uniqueSlug = `${baseSlug}-${Math.random().toString(36).substring(2, 6)}`

    const newOrg = await createOrganizationForUser(userId, name, uniqueSlug, userEmail)

    const response = {
      id: newOrg.id,
      name: newOrg.name,
      slug: newOrg.slug,
      billing_email: newOrg.billing_email,
      billing_partner: null,
      organization_requires_mfa: false,
      opt_in_tags: [],
      restriction_status: null,
      restriction_data: null,
      usage_billing_enabled: false,
      stripe_customer_id: null,
      subscription_id: 'enterprise-sub',
      plan: {
        id: 'enterprise',
        name: 'Enterprise',
      },
    }

    return res.status(200).json(response)
  } catch (error: any) {
    console.error('Error creating organization:', error)
    return res.status(500).json({ error: { message: error.message || 'Internal Server Error' } })
  }
}
