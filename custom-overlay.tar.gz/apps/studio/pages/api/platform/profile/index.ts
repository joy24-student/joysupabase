import type { NextApiRequest, NextApiResponse } from 'next'
import type { JwtPayload } from '@supabase/supabase-js'

import { apiWrapper } from '@/lib/api/apiWrapper'
import { getOrganizationsForUser, getProjectsForUser } from '@/lib/api/db'

export default (req: NextApiRequest, res: NextApiResponse) =>
  apiWrapper(req, res, handler, { withAuth: true })

async function handler(req: NextApiRequest, res: NextApiResponse, claims?: JwtPayload) {
  const { method } = req

  if (!claims || !claims.sub) {
    return res.status(401).json({ error: { message: 'Unauthorized: missing user claims' } })
  }

  const userId = claims.sub

  switch (method) {
    case 'GET':
      return handleGet(req, res, userId, claims)
    default:
      res.setHeader('Allow', ['GET'])
      res.status(405).json({ data: null, error: { message: `Method ${method} Not Allowed` } })
  }
}

const handleGet = async (_req: NextApiRequest, res: NextApiResponse, userId: string, claims: JwtPayload) => {
  try {
    const orgs = await getOrganizationsForUser(userId)
    const dbProjects = await getProjectsForUser(userId)

    const orgsWithProjects = orgs.map((org: any) => {
      const orgProjects = dbProjects
        .filter((p: any) => p.organization_id === org.id)
        .map((p: any) => ({
          id: p.id,
          ref: p.ref,
          name: p.name,
          organization_id: p.organization_id,
          cloud_provider: 'localhost',
          status: p.status || 'ACTIVE_HEALTHY',
          region: 'local',
          inserted_at: p.created_at || new Date().toISOString(),
          connectionString: '',
        }))

      return {
        id: org.id,
        name: org.name,
        slug: org.slug,
        billing_email: org.billing_email,
        projects: orgProjects,
      }
    })

    const response = {
      id: userId,
      primary_email: claims.email || 'user@example.com',
      username: claims.email ? claims.email.split('@')[0] : 'user',
      first_name: '',
      last_name: '',
      organizations: orgsWithProjects,
    }

    return res.status(200).json(response)
  } catch (error: any) {
    console.error('Error fetching profile:', error)
    return res.status(500).json({ error: { message: error.message || 'Internal Server Error' } })
  }
}
