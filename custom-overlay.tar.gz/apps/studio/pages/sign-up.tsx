import { FirebaseAuthForm } from '@/components/interfaces/SignIn/FirebaseAuthForm'
import { SignInLayout } from '@/components/layouts/SignInLayout/SignInLayout'
import type { NextPageWithLayout } from '@/types'

const SignUpPage: NextPageWithLayout = () => {
  return <FirebaseAuthForm />
}

SignUpPage.getLayout = (page) => (
  <SignInLayout heading="Create Account" subheading="Get started with Firebase Auth" inboundFlow="sign-up">
    {page}
  </SignInLayout>
)

export default SignUpPage
