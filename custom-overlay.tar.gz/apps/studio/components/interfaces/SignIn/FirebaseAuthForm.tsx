import { useState } from 'react'
import { toast } from 'sonner'
import { Button, Input } from 'ui'

export const FirebaseAuthForm = () => {
  const [isSignUp, setIsSignUp] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [googleLoading, setGoogleLoading] = useState(false)

  const saveTokenAndRedirect = (token: string) => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('supabase.firebase.auth.token', token)
      window.localStorage.setItem('supabase.dashboard.auth.token', token)
    }
    window.location.href = '/organizations'
  }

  const handleSocialSignIn = async () => {
    setGoogleLoading(true)
    try {
      const { signInWithPopup } = await import('firebase/auth')
      const { firebaseAuth, googleProvider } = await import('@/lib/firebase/client')

      const result = await signInWithPopup(firebaseAuth, googleProvider)
      const token = await result.user.getIdToken()

      toast.success(`Logged in as ${result.user.email || result.user.displayName}`)
      saveTokenAndRedirect(token)
    } catch (error: any) {
      if (error?.code === 'auth/unauthorized-domain') {
        toast.error(
          `Add "${window.location.hostname}" to Firebase Console -> Authentication -> Settings -> Authorized domains, or sign in with Email & Password below.`
        )
      } else {
        toast.error(`Google Login Error: ${error.message}`)
      }
    } finally {
      setGoogleLoading(false)
    }
  }

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !password) {
      toast.error('Please enter both email and password.')
      return
    }

    setLoading(true)
    try {
      const { firebaseAuth } = await import('@/lib/firebase/client')

      let userCredential
      if (isSignUp) {
        const { createUserWithEmailAndPassword } = await import('firebase/auth')
        userCredential = await createUserWithEmailAndPassword(firebaseAuth, email, password)
        toast.success('Account created successfully!')
      } else {
        const { signInWithEmailAndPassword } = await import('firebase/auth')
        userCredential = await signInWithEmailAndPassword(firebaseAuth, email, password)
        toast.success('Signed in successfully!')
      }

      const token = await userCredential.user.getIdToken()
      saveTokenAndRedirect(token)
    } catch (error: any) {
      toast.error(`Authentication Error: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex flex-col gap-5 w-full max-w-sm mx-auto">
      {/* Firebase Social Login */}
      <Button
        block
        size="large"
        variant="outline"
        loading={googleLoading}
        onClick={handleSocialSignIn}
      >
        Continue with Google (Firebase)
      </Button>

      {/* Or Divider */}
      <div className="relative my-2">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-strong" />
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-2 text-sm text-foreground bg-studio">or</span>
        </div>
      </div>

      {/* Firebase Email & Password Form */}
      <form onSubmit={handleEmailAuth} className="flex flex-col gap-4">
        <div className="flex flex-col gap-1">
          <label className="text-xs text-foreground-light">Email address</label>
          <Input
            type="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-xs text-foreground-light">Password</label>
          <Input
            type="password"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <Button block size="large" type="submit" loading={loading}>
          {isSignUp ? 'Sign Up with Firebase' : 'Sign In with Firebase'}
        </Button>
      </form>

      {/* Toggle between Sign In and Sign Up */}
      <div className="self-center mt-4 text-sm">
        <span className="text-foreground-light">
          {isSignUp ? 'Already have an account?' : "Don't have an account?"}
        </span>{' '}
        <button
          type="button"
          onClick={() => setIsSignUp(!isSignUp)}
          className="underline transition text-foreground hover:text-foreground-light font-medium"
        >
          {isSignUp ? 'Sign in' : 'Sign up'}
        </button>
      </div>
    </div>
  )
}
