import { useState } from 'react'
import { toast } from 'sonner'
import { Button } from 'ui'

export const SignInWithFirebase = () => {
  const [loading, setLoading] = useState(false)

  async function handleFirebaseSignIn() {
    setLoading(true)
    try {
      const { signInWithPopup } = await import('firebase/auth')
      const { firebaseAuth, googleProvider } = await import('@/lib/firebase/client')

      const result = await signInWithPopup(firebaseAuth, googleProvider)
      const token = await result.user.getIdToken()

      if (typeof window !== 'undefined') {
        localStorage.setItem('supabase.dashboard.auth.token', token)
      }

      toast.success(`Logged in as ${result.user.email || result.user.displayName}`)
      window.location.href = '/organizations'
    } catch (error: any) {
      toast.error(`Firebase Login Error: ${error.message}`)
      setLoading(false)
    }
  }

  return (
    <Button
      block
      size="large"
      variant="outline"
      loading={loading}
      onClick={handleFirebaseSignIn}
    >
      Continue with Firebase (Google)
    </Button>
  )
}
