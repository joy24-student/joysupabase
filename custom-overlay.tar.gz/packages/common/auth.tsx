'use client'

import type { AuthError, Session } from '@supabase/supabase-js'
import {
  createContext,
  PropsWithChildren,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react'

import { clearLocalStorage } from './constants/local-storage'
import { gotrueClient, type User } from './gotrue'

export type { User }

export const FIREBASE_TOKEN_KEY = 'supabase.firebase.auth.token'
export const DASHBOARD_TOKEN_KEY = 'supabase.dashboard.auth.token'

export function getFirebaseSessionFromStorage(): Session | null {
  if (typeof window === 'undefined') return null
  try {
    const fbToken = window.localStorage.getItem(FIREBASE_TOKEN_KEY)
    const dashToken = window.localStorage.getItem(DASHBOARD_TOKEN_KEY)
    const raw = fbToken || dashToken
    if (!raw) return null

    const parts = raw.split('.')
    if (parts.length !== 3) return null

    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/')
    const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4)
    const payload = JSON.parse(window.atob(padded))

    // Verify it is a Firebase JWT or custom JWT (not an expired GoTrue session JSON)
    if (!payload || typeof payload !== 'object') return null

    // Persist in FIREBASE_TOKEN_KEY so gotrueClient never wipes it
    if (!fbToken) {
      window.localStorage.setItem(FIREBASE_TOKEN_KEY, raw)
    }

    const uid = payload.sub || payload.user_id || 'firebase-user'
    const email = payload.email || 'user@example.com'
    const now = Math.floor(Date.now() / 1000)

    return {
      access_token: raw,
      refresh_token: 'firebase-refresh-token',
      expires_in: 86400,
      expires_at: payload.exp && payload.exp > now ? payload.exp : now + 86400,
      token_type: 'bearer',
      user: {
        id: uid,
        aud: 'authenticated',
        role: 'authenticated',
        email,
        email_confirmed_at: new Date().toISOString(),
        phone: '',
        confirmed_at: new Date().toISOString(),
        last_signed_in_at: new Date().toISOString(),
        app_metadata: { provider: 'firebase', providers: ['firebase'] },
        user_metadata: { email },
        identities: [],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    } as unknown as Session
  } catch {
    return null
  }
}

const DEFAULT_SESSION: any = {
  access_token: undefined,
  expires_at: 0,
  expires_in: 0,
  refresh_token: '',
  token_type: '',
  user: {
    aud: '',
    app_metadata: {},
    confirmed_at: '',
    created_at: '',
    email: '',
    email_confirmed_at: '',
    id: '',
    identities: [],
    last_signed_in_at: '',
    phone: '',
    role: '',
    updated_at: '',
    user_metadata: {},
  },
} as unknown as Session

/* Auth Context */

type AuthState =
  | {
      session: Session | null
      error: AuthError | null
      isLoading: false
    }
  | {
      session: null
      error: AuthError | null
      isLoading: true
    }

export type AuthContext = { refreshSession: () => Promise<Session | null> } & AuthState

export const AuthContext = createContext<AuthContext>({
  session: null,
  error: null,
  isLoading: true,
  refreshSession: () => Promise.resolve(null),
})

export type AuthProviderProps = {
  alwaysLoggedIn?: boolean
}

export const AuthProvider = ({
  alwaysLoggedIn,
  children,
}: PropsWithChildren<AuthProviderProps>) => {
  const [state, setState] = useState<AuthState>({ session: null, error: null, isLoading: true })

  useEffect(() => {
    const fbSession = getFirebaseSessionFromStorage()
    if (fbSession) {
      setState({ session: fbSession, error: null, isLoading: false })
      return
    }

    let mounted = true
    gotrueClient.initialize().then(({ error }) => {
      if (!mounted) return
      const currentFb = getFirebaseSessionFromStorage()
      if (currentFb) {
        setState({ session: currentFb, error: null, isLoading: false })
        return
      }
      if (error !== null) {
        setState((prev) => ({ ...prev, error, isLoading: false }))
      }
    })

    return () => {
      mounted = false
    }
  }, [])

  // Keep the session in sync
  useEffect(() => {
    const fbSession = getFirebaseSessionFromStorage()
    if (fbSession) {
      setState({ session: fbSession, error: null, isLoading: false })
      return
    }

    const {
      data: { subscription },
    } = gotrueClient.onAuthStateChange((_event, session) => {
      const currentFb = getFirebaseSessionFromStorage()
      if (currentFb) {
        setState({ session: currentFb, error: null, isLoading: false })
        return
      }
      setState((prev) => ({
        session,
        error: session !== null ? null : prev.error,
        isLoading: false,
      }))
    })

    return subscription.unsubscribe
  }, [])

  // Helper method to refresh the session.
  const refreshSession = useCallback(async () => {
    const fbSession = getFirebaseSessionFromStorage()
    if (fbSession) {
      setState({ session: fbSession, error: null, isLoading: false })
      return fbSession
    }
    const {
      data: { session },
    } = await gotrueClient.refreshSession()

    return session
  }, [])

  const value = useMemo(() => {
    if (alwaysLoggedIn) {
      return { session: DEFAULT_SESSION, error: null, isLoading: false, refreshSession } as const
    } else {
      return { ...state, refreshSession } as const
    }
  }, [state, refreshSession, alwaysLoggedIn])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

/* Auth Utils */

export const useAuth = () => useContext(AuthContext)

export const useSession = () => useAuth().session

export const useUser = () => {
  const user = useSession()?.user ?? null

  if (user && (user as any).__isUserNotAvailableProxy) return null

  return user
}

export const useIsUserLoading = () => useAuth().isLoading

export const useIsLoggedIn = () => {
  const user = useUser()

  return user !== null
}

export const useAuthError = () => useAuth().error

export const useIsMFAEnabled = () => {
  const user = useUser()

  return user !== null && user.factors && user.factors.length > 0
}

export const signOut = async () => {
  if (typeof window !== 'undefined') {
    window.localStorage.removeItem(FIREBASE_TOKEN_KEY)
    window.localStorage.removeItem(DASHBOARD_TOKEN_KEY)
  }
  return await gotrueClient.signOut()
}

export const logOut = async () => {
  await signOut()
  clearLocalStorage()
}

gotrueClient.onAuthStateChange((_event, _session) => {})

/**
 * Gets a current access token.
 *
 * Checks Firebase JWT first, then falls back to GoTrue session.
 */
export async function getAccessToken() {
  // ignore if server-side
  if (typeof window === 'undefined') return undefined

  const fbSession = getFirebaseSessionFromStorage()
  if (fbSession?.access_token) {
    return fbSession.access_token
  }

  const {
    data: { session },
    error,
  } = await gotrueClient.getSession()
  if (error) {
    return undefined
  }

  return session?.access_token
}
